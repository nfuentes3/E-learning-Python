def imprimir(mensaje):
    marco=len(mensaje)
    print( f"""
        {"_"*marco}
        {mensaje}
        {"_"*marco}
        """)