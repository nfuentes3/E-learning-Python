from tkinter import *


#Colores de fuente
COLOR_ERROR = "red"
COLOR_OK = "green"
COLOR_INFO = "black"
COLOR_TITUTLO = "white"
COLOR_SUBTITULO = "black"


#Estilos de fuente 
TEXT_INFO = ("Arial", 13, "bold")
TEXT_TITULO = ("Arial", 11, "bold")
TEXT_HEADER = ("Arial", 9, "bold")
TEXT_BUTTON = ("Arial", 9, "bold")

#Color de fondo (tema)
MODO_OSCURO = "#353635"
MODO_CLARO = "#ededed"
MODO_VERDE = "#1cba46"

