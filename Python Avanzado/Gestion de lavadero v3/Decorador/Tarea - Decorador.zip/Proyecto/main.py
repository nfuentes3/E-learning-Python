from controlador import *

if __name__ == "__main__":
    app = Controller()
    db = OperacionesDB()
    app.ventana.mainloop()
